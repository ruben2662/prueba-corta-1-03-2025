public class Auto extends Vehiculo {
    private int puertas;

    public Auto(String marca, String modelo, int anio, int puertas) {
        super(marca, modelo, anio);
        this.puertas = puertas;
    }

    @Override
    public String obtenerInfo() {
        return "Auto: " + super.obtenerInfo() + ", " + puertas + " puertas";
    }
}

