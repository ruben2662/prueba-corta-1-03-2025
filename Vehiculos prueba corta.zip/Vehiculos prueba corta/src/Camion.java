public class Camion extends Vehiculo {
    private double capacidad;

    public Camion(String marca, String modelo, int anio, double capacidad) {
        super(marca, modelo, anio);
        this.capacidad = capacidad;
    }

    @Override
    public String obtenerInfo() {
        return "Camion: " + super.obtenerInfo() + ", Capacidad: " + capacidad + " toneladas";
    }
}
