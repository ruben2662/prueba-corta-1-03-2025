public class Vehiculo{
    protected String marca, modelo;
    protected int anio;

    public Vehiculo(String marca, String modelo, int anio) {
        this.marca = marca;
        this.modelo = modelo;
        this.anio = anio;
    }

    public String obtenerInfo() {
        return marca + " " + modelo + " (" + anio + ")";
    }
}
