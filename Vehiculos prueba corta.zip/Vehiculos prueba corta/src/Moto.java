public class Moto extends Vehiculo {
    private String tipo;

    public Moto(String marca, String modelo, int anio, String tipo) {
        super(marca, modelo, anio);
        this.tipo = tipo;
    }

    @Override
    public String obtenerInfo() {
        return "Moto: " + super.obtenerInfo() + ", Tipo: " + tipo;
    }
}
