import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
    public class VerVehiculos extends JFrame {

        public VerVehiculos(ArrayList<Vehiculo> vehiculos) {
            setTitle("Lista de Vehículos");
            setSize(400, 300);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            setLayout(new BorderLayout());

            DefaultListModel<String> listModel = new DefaultListModel<>();
            for (Vehiculo v : vehiculos) {
                listModel.addElement(v.obtenerInfo());
            }

            JList<String> listaVehiculos = new JList<>(listModel);
            JScrollPane scrollPane = new JScrollPane(listaVehiculos);
            add(scrollPane, BorderLayout.CENTER);

            JButton btnCerrar = new JButton("Cerrar");
            btnCerrar.addActionListener(e -> dispose());
            add(btnCerrar, BorderLayout.SOUTH);

            setLocationRelativeTo(null);
            setVisible(true);
        }
    }

