import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;

public class Aplicacion extends JFrame {
    private JComboBox<String> tipoCombo;
    private JTextField marcaField, modeloField, anioField, extraField;
    private DefaultListModel<String> listModel;
    private JList<String> listaVehiculos;
    private ArrayList<Vehiculo> vehiculos = new ArrayList<>();

    public Aplicacion() {
        setTitle("Gestión de Vehículos");
        setSize(400, 320);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        JLabel lblTipo = new JLabel("Tipo de Vehículo:");
        lblTipo.setBounds(10, 10, 120, 20);
        add(lblTipo);

        tipoCombo = new JComboBox<>(new String[]{"Auto", "Moto", "Camion"});
        tipoCombo.setBounds(140, 10, 200, 20);
        add(tipoCombo);

        JLabel lblMarca = new JLabel("Marca:");
        lblMarca.setBounds(10, 40, 120, 20);
        add(lblMarca);

        marcaField = new JTextField();
        marcaField.setBounds(140, 40, 200, 20);
        add(marcaField);

        JLabel lblModelo = new JLabel("Modelo:");
        lblModelo.setBounds(10, 70, 120, 20);
        add(lblModelo);

        modeloField = new JTextField();
        modeloField.setBounds(140, 70, 200, 20);
        add(modeloField);

        JLabel lblAnio = new JLabel("Año:");
        lblAnio.setBounds(10, 100, 120, 20);
        add(lblAnio);

        anioField = new JTextField();
        anioField.setBounds(140, 100, 200, 20);
        add(anioField);

        JLabel lblExtra = new JLabel("Especificación:");
        lblExtra.setBounds(10, 130, 120, 20);
        add(lblExtra);

        extraField = new JTextField();
        extraField.setBounds(140, 130, 200, 20);
        add(extraField);

        JButton btnAgregar = new JButton("Agregar Vehículo");
        btnAgregar.setBounds(10, 160, 330, 30);
        add(btnAgregar);

        JButton btnVerVehiculos = new JButton("Ver Vehículos");
        btnVerVehiculos.setBounds(10, 200, 330, 30);
        add(btnVerVehiculos);

        listModel = new DefaultListModel<>();
        listaVehiculos = new JList<>(listModel);
        JScrollPane scrollPane = new JScrollPane(listaVehiculos);
        scrollPane.setBounds(10, 240, 330, 60);
        add(scrollPane);

        btnAgregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarVehiculo();
            }
        });

        btnVerVehiculos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                verVehiculos();
            }
        });
    }

    private void agregarVehiculo() {
        String tipo = (String) tipoCombo.getSelectedItem();
        String marca = marcaField.getText().trim();
        String modelo = modeloField.getText().trim();
        String anioTexto = anioField.getText().trim();
        String extra = extraField.getText().trim();

        if (marca.isEmpty() || modelo.isEmpty() || anioTexto.isEmpty() || extra.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos los campos deben estar llenos", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            int anio = Integer.parseInt(anioTexto);
            Vehiculo vehiculo = null;

            if ("Auto".equals(tipo)) {
                int puertas = Integer.parseInt(extra);
                vehiculo = new Auto(marca, modelo, anio, puertas);
            } else if ("Moto".equals(tipo)) {
                vehiculo = new Moto(marca, modelo, anio, extra);
            } else if ("Camion".equals(tipo)) {
                double capacidad = Double.parseDouble(extra);
                vehiculo = new Camion(marca, modelo, anio, capacidad);
            }

            if (vehiculo != null) {
                vehiculos.add(vehiculo);
                listModel.addElement(vehiculo.obtenerInfo());
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "El año y la especificación deben ser valores numéricos válidos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void verVehiculos() {
        listModel.clear(); // Limpiar la lista antes de mostrar los vehículos
        for (Vehiculo v : vehiculos) {
            listModel.addElement(v.obtenerInfo()); // Añadir cada vehículo a la lista
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new Aplicacion().setVisible(true);
        });
    }
}


